# Fake-News-Detection
Fake News Classifier using NLP techniques
